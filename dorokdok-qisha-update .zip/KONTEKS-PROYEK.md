# KONTEKS PROYEK — Aplikasi Dorokdok Qisha
_Disusun 4 November 2026. Unggah file ini (beserta zip-nya) ke percakapan Claude baru, lalu tulis:_
**"Ini konteks proyek aplikasi Dorokdok Qisha saya. Baca dulu, lalu lanjutkan dari bagian Status & Langkah Berikutnya."**

---

## 1. Usaha
- **Nama:** Dorokdok Qisha — kerupuk kulit sapi asli ("Camilan Semua Generasi").
- **Kontak:** IG/TikTok @dorokdokqisha · dorokdokqisha@gmail.com · WA 0881026870975.
- **Produksi per batch:** ±200 kg kulit (lembaran atau cacagan) → dikemas berbagai ukuran.
- **Proses olahan (7 tahap):** Lembaran → Direndam → Dicincang → Dijemur → Dibumbu → Dilapo → Digoreng.
  - Bisa mulai dari **cacagan** (sudah dicincang) → tahap Lembaran, Rendam, Cincang dilewati.
  - Penimbangan biasa: saat beli, setelah kering dipotong (keringan), setelah dilapo (lapoan, basah minyak).
  - Berat produk jadi memakai patokan **label kemasan** (±), bukan timbang ulang.
- **Ukuran kemasan:** 20 gr (kecil), 50, 70, 100, 250, 500 gr, 1 kg, 2 kg, 5 kg.

## 2. Pengurus (Struktur Organisasi)
Komisaris **Dince Siti Sadiah** → CEO **Eka Mohammad Faisal** → CFO **Rhesta Octapiana** dan CMO **Rustiana** → (di bawah CMO) Kepala Staf **Zulkifli**.

## 3. Pengguna aplikasi
| Peran | Email | Hak |
|---|---|---|
| Pengelola (pemegang keuangan, juga Investor 2) | dorokdokqisha@gmail.com | lihat + ubah semua |
| Investor 1 | 2rcraftproject@gmail.com | lihat semua, tanpa ubah |

**Bagi hasil:** laba bersih per batch dibagi **50 : 50** untuk 2 investor. Batch rugi tidak dibagikan.

## 4. Harga jual
| Ukuran | Langganan (paling sering) | Umum/satuan | Reseller (MOQ) | Distributor (MOQ) |
|---|---|---|---|---|
| 20 gr | 1.500 | – | – | – |
| 50 gr | 4.000 | – | – | – |
| 70 gr | – | 12.000 | 10.500 (50) | 8.500 (70) |
| 100 gr | 8.000 | 15.000 | 12.500 (30) | 10.500 (50) |
| 250 gr | – | 35.000 | 31.500 (20) | 29.500 (30) |
| 500 gr | – | 70.000 | 61.000 (15) | 57.500 (20) |
| 1 kg | 100.000 | 125.000 | 118.000 (10) | 112.000 (15) |
| 2 kg | – | 245.000 | 235.000 (5) | 225.000 (10) |
| 5 kg | – | 620.000 | 595.000 (3) | 570.000 (5) |
Original dan Pedas harganya sama. Kolom kosong di aplikasi → pakai harga Langganan, lalu Umum.

## 5. Payroll
- Periode **2 minggu**. Harian: **Rp50.000/hari**, **Rp25.000/setengah hari**, **upah bungkus Rp25.000/hari**. Libur tidak dibayar.
- **Rustiana (Marketing/CMO):** Rp1.000.000 per 2 minggu → dibagi 14 hari = **Rp71.429 per hari masuk**.
- Pembebanan: di PDF lama semua upah = **"Gaji produksi" di Biaya Produksi (HPP)**. Di aplikasi ada pilihan
  _Biaya produksi · Gaji produksi (HPP)_ atau _Beban operasional · Gaji marketing_. Rustiana diset ke **Beban operasional**.
- Uang makan = Beban operasional.

## 6. Riwayat keuangan (dari laporan PDF)
| Batch | Periode | Pendapatan | Biaya produksi | Beban op. | Laba bersih | Hasil jadi |
|---|---|---|---|---|---|---|
| B001 | 24 Jun – 21 Jul 2026 | 14.312.500 | 19.023.504 | 1.622.500 | **−6.333.504** | 140 kg |
| B002 | 22 Jul – 19 Agu 2026 | 21.824.500 | 17.226.146 | 1.637.500 | **+2.960.854** | 260 kg (keringan 213, lapoan 210) |
| B003 | 20 Agu – 20 Okt 2026 | 24.215.000 | 17.682.667 | 1.790.000 | **+4.742.333** | 344 kg (keringan 202, lapoan 214) |

**Saldo awal aplikasi per 21 Okt 2026** (akhir B003, sudah dipisah dengan benar):
Kas 17.903.187 + Aset tetap 4.568.000 = **22.471.187** = Modal disetor 21.101.504 (16.101.504 B001 + 5.000.000 B002) + Laba ditahan 1.369.683.

Koreksi atas PDF lama: tanda kurung pada laba B002/B003 salah (angkanya positif); arus kas B001 beban op. tertulis 1.616.500 (seharusnya 1.622.500); aset belum disusutkan; stok akhir selalu dianggap nol.
Batch 004 mulai sekitar **28 Okt 2026** (belum diinput ke aplikasi).

**Aset tetap (22 item, total Rp4.568.000, tgl perolehan 24 Jun 2026):** Katel 114 cm 1.500.000; Katel 190 cm 800.000; Serok 2 pcs 400.000; Serok dedek 150.000; Klem 4 pcs 12.000; Kompor Mawar 2 pcs 300.000; Regulator 2 pcs 180.000; Selang kompor 4 m 114.000; Sealer Origin 285.000; Gembok A 31.500; Gembok B 32.000; Engsel 2 pcs 16.000; Gayung minyak 37.500; Corong 20 cm 10.000; Drum 170.000; Jerigen 20.000; Terpal 2 pcs 240.000; Seng 68.000; Seng 90 cm 42.000; Karung 10.000; Bedog 2 pcs 70.000; Timbangan 80.000.

## 7. Aturan akuntansi di aplikasi
- **Buku besar otomatis berpasangan** (debit = kredit) dari semua catatan → Neraca selalu seimbang (ada indikator ✓).
- **HPP batch** = total biaya produksi × (gram terjual ÷ gram dikemas). Sisa = persediaan.
- **Biaya produksi:** kulit, bahan penolong, kemasan & label, LPG, biaya produksi lain, gaji produksi.
- **Beban usaha:** operasional (uang makan, bensin, lapak, listrik, dst.), gaji marketing, **penyusutan**.
- **Penyusutan:** garis lurus 48 bulan (peralatan kelompok 1, 25%/thn), dihitung harian, mulai **21 Okt 2026** (B001–B003 tidak diubah).
- **Penjualan:** Tunai (langsung kas) · Piutang (bayar bertahap) · Konsinyasi (catat laku & retur; pendapatan = yang laku).
- **Stok:** Dikemas − Terjual − Dititipkan = Sisa gudang, per ukuran per batch.
- **Kas keluar belum dibayar** → Utang usaha. **Payroll belum dibayar** → Utang gaji.
- **Bagi hasil** dicatat di kas kategori "Bagi hasil investor" → mengurangi kas & ekuitas (prive), bukan beban.
- Laba bersih = Pendapatan − HPP − Beban operasional − Penyusutan.

## 8. Fitur aplikasi (menu)
Ringkasan · Produksi (lampu 7 tahap: ⚪ menunggu, 🟡 berjalan berkedip, 🟢 selesai, 🔴 lewat target, garis putus = dilewati; target hari: Lembaran 1, Rendam 1, Cincang 2, Jemur 3, Bumbu 1, Lapo 2, Goreng 4) · Stok · Penjualan · Buku Kas · Payroll · Laporan (Laba Rugi per batch, Neraca, Arus Kas, Perubahan Ekuitas) · Investor · Organisasi (bagan + foto) · Pengaturan (harga, investor, target, saldo awal, penyusutan, cadangan/pulihkan JSON).

## 9. Teknis
- **Versi Claude (artefak):** satu file HTML, data di database artefak (`dq/v1/...`), salinan otomatis di perangkat.
- **Versi website sendiri (aktif):**
  - Hosting **GitHub Pages**: `https://dorokdokqisha.github.io/<nama-repo>/` (akun GitHub: dorokdokqisha).
  - Database & login **Firebase** proyek `dorokdok-qisha` (Firestore lokasi Jakarta asia-southeast2, Auth Google aktif, Authorized domain `dorokdokqisha.github.io` sudah ditambah).
  - File di repo: index.html, config.js, adapter.js, sw.js, manifest.webmanifest, icon-192.png, icon-512.png.
  - `adapter.js` menyediakan `window.claude.use('db'|'user'|'downloads')` di atas Firebase, jadi kode aplikasi sama persis dengan versi artefak.
  - Login memakai **pop-up** (redirect diblokir Chrome HP untuk domain github.io).
- **Struktur data Firestore** (koleksi di bawah `dq/v1/`): `meta/main` (harga, moq, investor, target, saldoAwal, aset, mulaiSusut, umurAset) · `batch` · `jual` · `kas` · `kemas` · `pekerja` · `payroll` · `org`.
- **Firestore Rules yang dipasang:**
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /dq/{path=**} {
      allow read: if request.auth != null
        && request.auth.token.email in ['dorokdokqisha@gmail.com', '2rcraftproject@gmail.com'];
      allow write: if request.auth != null
        && request.auth.token.email in ['dorokdokqisha@gmail.com'];
    }
  }
}
```
- Menambah investor/pengelola baru → ubah **config.js** (GitHub) **dan** Rules (Firebase).
- Update aplikasi → unggah file yang berubah ke GitHub (Add file → Upload files → Commit). Data aman di Firebase.

## 10. Status & langkah berikutnya
- [x] Firebase dibuat, Rules, Auth Google, Authorized domain.
- [x] Website online di GitHub Pages, login pengelola berhasil.
- [ ] Pulihkan data: website → Pengaturan → Pulihkan dari file → `cadangan-data-2026-11-04.json`.
- [ ] Uji akun investor (2rcraftproject@gmail.com) → harus "Investor · lihat saja".
- [ ] Input Batch 004 (mulai ±28 Okt 2026) beserta biaya, kemasan, dan penjualannya.
- [ ] Tambah pekerja produksi di Payroll.
- [ ] Catat bagi hasil B002/B003 bila sudah dibayarkan.
- [ ] Unggah foto pengurus di menu Organisasi.
- [ ] (Opsional) Pasang ke layar HP / buat APK lewat pwabuilder.com.

## 11. Preferensi pemilik
- Bahasa Indonesia, penjelasan **pelan-pelan langkah demi langkah**, sebagian besar kerja **dari HP**.
- Tampilan formal, elegan, profesional (marun & emas sesuai logo), bukan gaya "AI".
- Hemat token, tapi hasil maksimal; perhitungan akuntansi harus logis dan seimbang.
