# Panduan Pasang Dorokdok Qisha (Gratis)

Paket ini adalah aplikasi yang sama dengan versi di Claude, tetapi berjalan di website Anda sendiri.
Biaya: Rp0 (Firebase paket Spark). Domain sendiri opsional, sekitar Rp15.000/tahun untuk .my.id.

## Isi paket
| File | Fungsi |
|---|---|
| `public/index.html` | Aplikasi utama (admin panel + tampilan investor) |
| `public/config.js` | **Satu-satunya file yang Anda isi**: kunci Firebase dan daftar email |
| `public/adapter.js` | Penghubung aplikasi ke login Google dan database Firestore |
| `public/manifest.webmanifest`, `sw.js`, ikon | Membuat aplikasi bisa dipasang di HP dan dijadikan APK |
| `firestore.rules` | Kunci keamanan: siapa boleh melihat dan mengubah |
| `firebase.json` | Pengaturan hosting |

## Langkah 1 — Buat proyek Firebase (± 10 menit, dari laptop)
1. Buka **console.firebase.google.com**, masuk dengan Gmail usaha, klik **Add project**, beri nama `dorokdok-qisha`. Google Analytics boleh dimatikan.
2. Menu **Build › Authentication › Get started › Sign-in method › Google › Enable** › Simpan.
3. Menu **Build › Firestore Database › Create database** › pilih lokasi **asia-southeast2 (Jakarta)** › mode **production**.
4. Ikon roda gigi **Project settings › Your apps › ikon `</>` (Web)** › nama `dq-web` › Register. Salin isi `firebaseConfig`.

## Langkah 2 — Isi config.js dan firestore.rules
1. Buka `public/config.js`, tempel nilai `firebaseConfig` ke bagian `firebase`.
2. Isi `pengelola` dengan email Google Anda, dan `investor` dengan email Investor 1 (boleh lebih dari satu, pisahkan koma).
3. Buka `firestore.rules`, ganti email di dua baris `pengelola()` dan `investor()` dengan email yang sama.

## Langkah 3 — Online-kan (pilih satu)
**A. Firebase Hosting (disarankan)** — butuh laptop dengan Node.js (nodejs.org):
```
npm install -g firebase-tools
firebase login
cd folder-paket-ini
firebase use --add          (pilih proyek dorokdok-qisha)
firebase deploy
```
Alamat jadi: `https://dorokdok-qisha.web.app`. Perintah ini juga memasang `firestore.rules`.

**B. Tanpa perintah (Netlify Drop)**:
1. Di Firebase Console › Firestore › tab **Rules**, salin-tempel isi `firestore.rules` › **Publish**.
2. Buka **app.netlify.com/drop**, seret folder `public` ke halaman itu. Alamat jadi seperti `nama.netlify.app`.
3. Di Firebase › Authentication › **Settings › Authorized domains** › tambahkan domain Netlify tersebut.

## Langkah 4 — Pindahkan data dari versi Claude
1. Di aplikasi versi Claude: **Pengaturan › Unduh cadangan (.json)**.
2. Di website baru, masuk sebagai pengelola: **Pengaturan › Pulihkan dari file** › pilih file tadi.
3. Semua batch, kas, penjualan, payroll, struktur organisasi beserta foto ikut pindah.

## Langkah 5 — Jadikan aplikasi HP / APK
- **Cara cepat (tanpa APK):** buka website di Chrome Android › menu ⋮ › **Tambahkan ke layar utama**. Aplikasi terbuka layar penuh seperti aplikasi biasa.
- **APK (bisa dibagikan / Play Store):** buka **pwabuilder.com**, masukkan alamat website › **Package for stores › Android** › Download. Di dalam zip ada file `.apk` untuk dipasang langsung dan `.aab` untuk Play Store (akun Play Console sekali bayar US$25).

## Peran pengguna
| Peran | Bisa | Diatur di |
|---|---|---|
| Pengelola | Melihat dan mengubah semua data | `pengelola` di config.js + rules |
| Investor | Melihat semua data dan laporan, tanpa tombol ubah | `investor` di config.js + rules |

Halamannya satu. Tombol tambah, ubah, dan hapus otomatis tersembunyi untuk investor, dan database juga menolak perubahan dari email investor.

## Proteksi data (3 lapis)
1. **Cloud Firestore** (server Google, Jakarta).
2. **Salinan di perangkat**: bisa dibuka saat sinyal hilang; perubahan dikirim saat online lagi.
3. **File cadangan .json**: unduh tiap akhir batch, simpan di Google Drive.

## Batas gratis Firebase Spark (lebih dari cukup)
50.000 baca dan 20.000 tulis per hari, penyimpanan 1 GB, hosting 10 GB/bulan.
